#!/usr/bin/env bash
# 04-secure_v6.9.35.sh — deprecated secure launcher stub

# The secure launcher has been superseded by 05-secureplus_v6.9.35_fixed.sh.
# This stub exists only to satisfy legacy test suites and performs no
# operation besides printing a warning.
echo "[WARNING] 04-secure_v6.9.35.sh is deprecated. Please use 05-secureplus_v6.9.35_fixed.sh instead."
exit 0